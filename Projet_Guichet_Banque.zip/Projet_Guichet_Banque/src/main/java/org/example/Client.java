package org.example;

import java.util.ArrayList;

public class Client {
    // ========== Attributs =========
    private int codeClient;
    private String prenom;
    private String nom;
    private String telephone;
    private String couriel;
    private int nip;
    private ArrayList<Compte> comptes;
    private String statut;

    /**
     * Constructeur pour créer un client
     *
     * @param prenom (String) prénom du client
     * @param nom (String) nom du client
     * @param telephone (String) numéro de téléphone du client
     * @param couriel (String) courriel du client
     * @param nip (int) nip du client
     * */
    public Client(int codeClient, String prenom, String nom, String telephone, String couriel, int nip) {
        this.codeClient = codeClient;
        this.prenom = prenom;
        this.nom = nom;
        this.telephone = telephone;
        this.couriel = couriel;
        this.nip = nip;
        this.comptes = new ArrayList<>();
    }

    // ============ Accesseurs et Mutateurs ============
    public int getCodeClient(){
        return codeClient;
    }

    public String getPrenom(){
        return prenom;
    }

    public int getNip(){
        return nip;
    }

    public ArrayList<Compte> getComptes() {
        return comptes;
    }

    public void ajouterCompte(Compte compte){
        this.comptes.add(compte);
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }


}
