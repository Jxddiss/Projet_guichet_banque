# Projet_Guichet_Banque



## Équipe
Nicholson Rainville Jacques
Jamil Fayad

## TP-2
- Implémentation des classes
- Implémentation de la classe de test pour GestionnaireGuichet 
- Diagramme de classe

